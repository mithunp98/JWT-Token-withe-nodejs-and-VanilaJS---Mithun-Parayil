const express=require('express');
const app= express();
const jwt=require('jsonwebtoken');
require('dotenv').config()
const mysql = require("mysql")
const bodyParser = require("body-parser");
var cors = require('cors')
var bcrypt = require('bcryptjs');
const saltRounds = 10;

var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

app.listen(3000);
app.use(express.json())



var cors = require('cors')

app.use(cors())

const posts=[{
    username:"mithun",
    password:"mithun@123"
},
{
    username:"nuthim",
    password:"nuthim@123"
}]

/*--------------------------------------------*/
// sql connection
var con = mysql.createConnection({

    host: 'localhost',
    user: 'root',

    password: 'password',
    database: 'projdb'

});

 

con.connect((err) => {

    if (err) {

        return console.error('error: ' + err.message);

    }

 

    console.log('Connected to the MySQL server.');

});
/*--------------------------------------------*/





app.get('/posts',authenticateToken,(req,res)=>{
    res.json(posts.filter(post))
})

// app.post('/login',(req,res)=>{
    // const email=req.body.email;
    // const password = req.body.password;
    // if(req.body.email == undefined || req.body.password == undefined) {

    //     console.log("error");

    //     res.status(500).send({ error: "autentication failed" });

    // }

    // let query = `select name from users  where email = '${email}' and  password =  '${password}'   `

    // let username = req.body.username;

    //
   

    // Authenticate the user

   ////////////////////////////////////////////////////////
//         var email= req.body.email;
//         var password = req.body.password;
//         con.query('SELECT * FROM users WHERE email = ?',[email], async function (error, results, fields) {
//           if (error) {
//             res.send({
//               "code":400,
//               "failed":"error ocurred"
//             })
//           }else{
//             if(results.length >0){
//               const comparision = await bcrypt.compare(password, results[0].password)
//               if(comparision){
//                   res.send({
//                     "code":200,
//                     "success":"login sucessfull"
//                   })
//               }
//               else{
//                 res.send({
//                      "code":204,
//                      "success":"Email and password does not match"
//                 })
//               }
//             }
//             else{
//               res.send({
//                 "code":206,
//                 "success":"Email does not exits"
//                   });
//             }
//           }
//           });



 
//   const user={
//               uname:email,
//               pword:password
//               }
//   const accessToken=jwt.sign(user,process.env.ACCESS_TOKEN_SECERET)
//   res.json({accessToken:accessToken})

// })
////////////////////////////////////////////////

app.post("/login",urlencodedParser, function (req, res) {
    if(req.body.email == undefined || req.body.password == undefined) {
        console.log("error");
        res.status(500).send({ error: "autentication failed" });
    }
    let email = req.body.email;
    let password = req.body.password;
    // bcrypt.compareSync(password,x)
    console.log(email)
    let query = `select email from users  where email = '${email}' and  password =  '${password}'`
    con.query(query,(err,result)=>{
        if(err || result.length==0){
           res.status(500).send({error:"login failed"});
           console.log("error")
        }
        else{
                                 //    res.status(200).send({success:"login success"});
              let resp={
                  id:result[0].id,
                  displayname:result[0].name
              }
              let token=jwt.sign(resp,"secret",{expiresIn:270});
              res.status(200).send({auth:true,token:token});
               console.log(token)
        }
    })
});








//Registration

app.post('/registration', urlencodedParser,(req,res)=>{
    
    // console.log(req.body.name)
    console.clear()

    console.log(req.body.name)
    const user_name= req.body.name;
    const user_email=req.body.email;
    
   
    const user_password=req.body.password;
    
    // const hashPassword = bcrypt.hash(user_password, saltRounds);

    // console.log(hashPassword)

    // hashPassword.then(function(passresult){
    //     console.log(passresult)
    let query   = `INSERT INTO users (name, email, password) VALUES ("${user_name}", "${user_email}", "${user_password}")`;

    con.query(query,(err,result)=>{
 
      if(err) throw err
 
      res.json(result)
 
    })
  })
    // })
 
 
 
   




// middileware for verification
function authenticateToken(req,res,next){
    const authHeader= req.headers['authorization']
    const token =authHeader && authHeader.split(' ')[1]
    if(token== null) return res.sendStatus(401)
   
    jwt.verify(token, process.env.ACCESS_TOKEN_SECERET,(err,user=>{
        if(err)return res.sendStatus(403)
        req.user=user
        next()
        console.log(token)
    }))
}
